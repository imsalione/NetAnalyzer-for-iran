<div dir="rtl">

# 🌐 NetAnalyzer — پایش هوشمند اتصال اینترنت

<div align="center">

![Version](https://img.shields.io/badge/نسخه-3.0.0-blue?style=for-the-badge)
![Platform](https://img.shields.io/badge/سیستم‌عامل-Windows-0078D4?style=for-the-badge&logo=windows)
![Python](https://img.shields.io/badge/Python-3.10%2B-3776AB?style=for-the-badge&logo=python)
![License](https://img.shields.io/badge/مجوز-MIT-green?style=for-the-badge)

**ابزار پایش لحظه‌ای اینترنت با قابلیت تشخیص هوشمند فیلترشکن**

[⬇️ دانلود Portable](#-دانلود-و-نصب) • [🛠️ نصب از سورس](#-نصب-از-سورس-کد) • [📖 راهنما](#-راهنمای-استفاده)

</div>

---

## ✨ ویژگی‌های اصلی

- **🔍 پایش لحظه‌ای** — بررسی همزمان ۹ پلتفرم در هر چرخه
- **🛡️ تشخیص هوشمند VPN** — شناسایی خودکار فیلترشکن‌های مختلف (NetMod، v2rayN، Clash و ...)
- **⚡ واکنش سریع** — تشخیص تغییر وضعیت VPN در کمتر از ۵ ثانیه
- **📊 نمودار زنده** — نمایش گرافیکی ping بین‌المللی و داخلی
- **🎨 رابط کاربری فارسی** — طراحی مینیمال و زیبا در system tray
- **💾 Portable** — بدون نیاز به نصب، فایل EXE مستقل

---

## 🎯 وضعیت‌های قابل تشخیص

| وضعیت | توضیح | رنگ آیکون |
|---|---|:---:|
| اتصال کامل | دسترسی آزاد به همه سرویس‌ها | 🟢 |
| VPN فعال | فیلترشکن فعال و اتصال برقرار | 🟣 |
| فیلتر شبکه‌های اجتماعی | اینترنت داخلی و بین‌المللی فعال | 🟡 |
| اینترنت ملی | فقط دسترسی به سرویس‌های داخلی | 🟠 |
| اختلال DPI | مشکوک به فیلترینگ لایه برنامه | 🟡 |
| اتصال ناپایدار | قطعی‌های موقت | ⚪ |
| بدون اینترنت | عدم دسترسی | 🔴 |

---

## ⬇️ دانلود و نصب

### روش ۱ — فایل Portable (توصیه‌شده، بدون نیاز به Python)

1. به بخش [**Releases**](../../releases/latest) بروید
2. فایل `InternetMonitor_Portable.zip` را دانلود کنید
3. فایل زیپ را در هر پوشه‌ای extract کنید
4. روی `InternetMonitor.exe` دوبار کلیک کنید

> ✅ هیچ نصب اضافه‌ای لازم نیست. برنامه مستقیماً اجرا می‌شود.

---

### روش ۲ — نصب از سورس کد

#### پیش‌نیازها

- **Python 3.10** یا بالاتر — [دانلود از python.org](https://www.python.org/downloads/)
  > ⚠️ هنگام نصب Python، گزینه **"Add Python to PATH"** را حتماً تیک بزنید.

#### مراحل نصب

```bash
# ۱. دانلود پروژه
git clone https://github.com/YOUR_USERNAME/NetAnalyzer.git
cd NetAnalyzer

# ۲. نصب وابستگی‌ها
pip install -r requirements.txt

# ۳. اجرا
python main.py
```

یا از فایل batch استفاده کنید:

```
install.bat   ← نصب خودکار وابستگی‌ها
```

#### وابستگی‌ها

| کتابخانه | نسخه | کاربرد |
|---|---|---|
| PyQt6 | ≥ 6.5.0 | رابط کاربری گرافیکی |
| aiohttp | ≥ 3.9.0 | درخواست‌های HTTP ناهمزمان |
| qasync | ≥ 0.24.0 | یکپارچه‌سازی asyncio با Qt |
| loguru | ≥ 0.7.0 | ثبت رویدادها |

> برای پشتیبانی از پروکسی SOCKS5 (اختیاری):
> ```bash
> pip install aiohttp-socks
> ```

---

## 🛠️ ساخت فایل EXE

اگر می‌خواهید خودتان فایل EXE بسازید:

```bash
# ۱. نصب PyInstaller
pip install pyinstaller

# ۲. اجرای اسکریپت build
build_exe.bat
```

فایل نهایی در مسیر `dist\InternetMonitor.exe` قرار می‌گیرد.

---

## 📖 راهنمای استفاده

### شروع کار

پس از اجرا، آیکون رنگی نرم‌افزار در **system tray** (کنار ساعت ویندوز) ظاهر می‌شود.

### عملکردها

| عملکرد | روش |
|---|---|
| نمایش/مخفی پنجره وضعیت | کلیک چپ روی آیکون |
| منوی تنظیمات | کلیک راست روی آیکون |
| بررسی فوری | منو ← **بررسی اکنون** |
| تغییر بازه بررسی | منو ← **بازه بررسی** |
| انتخاب پلتفرم VPN | منو ← **پایش VPN** |

### پنجره وضعیت

- **Ping بین‌المللی (🌍)** — تأخیر به سرورهای خارجی
- **Ping داخلی (🏠)** — تأخیر به سرویس‌های ایرانی
- **نمودار** — تاریخچه ۴۰ نقطه آخر (راست‌کلیک برای تغییر حالت)
- **دکمه VPN** — نشانگر سریع وضعیت یک پلتفرم (🟢 متصل / 🔴 قطع)

### تشخیص VPN

نرم‌افزار به‌صورت خودکار فیلترشکن‌های زیر را شناسایی می‌کند:

- **NetMod** و فیلترشکن‌های TUN/TAP (بدون تنظیم اضافه)
- **v2rayN** — پروکسی HTTP روی پورت 10809
- **Clash / ClashX** — پروکسی HTTP روی پورت 7890
- **Shadowsocks** — پروکسی HTTP روی پورت 1087
- هر VPN با متغیر محیطی `HTTPS_PROXY` یا `HTTP_PROXY`

---

## 🏗️ ساختار پروژه

```
NetAnalyzer/
├── main.py                     # نقطه ورود برنامه
├── requirements.txt            # وابستگی‌های Python
├── install.bat                 # نصب خودکار
├── build_exe.bat               # ساخت فایل EXE
│
└── monitor/
    ├── core/                   # منطق اصلی (کد انگلیسی)
    │   ├── platform_monitor.py # پایش پلتفرم‌ها + تشخیص پروکسی
    │   ├── checker.py          # بررسی DNS / TCP / HTTP
    │   ├── classifier.py       # طبقه‌بندی هوشمند وضعیت
    │   ├── circuit_breaker.py  # مدیریت خطاهای تکراری
    │   ├── proxy_detector.py   # تشخیص خودکار فیلترشکن
    │   ├── latency_window.py   # پنجره لغزنده تأخیر
    │   ├── models.py           # مدل‌های داده
    │   ├── settings.py         # تنظیمات
    │   └── statistics.py       # آمار و آپتایم
    │
    ├── ui/                     # رابط کاربری (فارسی)
    │   ├── tray_app.py         # اپلیکیشن system tray
    │   └── minimal_window.py   # پنجره وضعیت + نمودار
    │
    └── utils/
        └── logger.py           # سیستم ثبت رویداد
```

---

## 📡 پلتفرم‌های پایش‌شده

| دسته | پلتفرم‌ها |
|---|---|
| 📱 شبکه‌های اجتماعی | Instagram، Telegram، Twitter/X |
| 🌍 بین‌المللی | Google، Cloudflare، Microsoft |
| 🏠 داخلی | IRNA، ISNA، Digikala |

---

## 🤝 مشارکت در توسعه

مشارکت‌ها خوشایند هستند! لطفاً:

1. پروژه را Fork کنید
2. یک branch جدید بسازید (`git checkout -b feature/my-feature`)
3. تغییرات را Commit کنید (`git commit -m 'Add my feature'`)
4. Push کنید (`git push origin feature/my-feature`)
5. یک Pull Request باز کنید

برای گزارش باگ یا پیشنهاد ویژگی، از بخش [Issues](../../issues) استفاده کنید.

---

## 📄 مجوز

این پروژه تحت [مجوز MIT](LICENSE) منتشر شده است.

---

<div align="center">

ساخته شده با ❤️ برای کاربران ایرانی

</div>

</div>
